t = None
r = None
print('ВІТАЄМО В КаЛьКуЛяТоРі Python)) Примітивний? Я знаю але е нікого не хвилює.')
number1 = int(input('Введи число 1: '))
number2 = int(input('Введи число 2: '))

ask = int(input('Яку операцію ти хочеш зробити? \n |Щоб додати натисни 1 \n |Щоб відняти натисни 2 \n |Щоб поділити '
                'натисни 3 \n |Ну і звісно щоб помножити натисни 4 ))) \n'))

if ask == 1:
    r = number1 + number2
    p = 'додавання'
    t = p
if ask == 2:
    r = number1 - number2
    l = 'віднімання'
    t = l
if ask == 3:
    try:
        r = float(number1 / number2)
        m = 'ділення'
        t = m
    except ZeroDivisionError:
        print('Вуйко-якби ти вчився в школі, то тоді би знав що на нуль ділити неможна >:-<!!!')
if ask == 4:
    r = number1 * number2
    n = 'множення'
    t = n

print(f'Результат {t}= {r}')
